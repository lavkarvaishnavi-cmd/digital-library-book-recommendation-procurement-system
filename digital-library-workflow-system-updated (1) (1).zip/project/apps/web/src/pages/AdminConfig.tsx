import React, { useEffect, useState } from "react";
import { api, ApiClientError } from "../api/client";

interface AdminUser { id: string; email: string; fullName: string; roles: string[]; isDemo: boolean; isActive: boolean }
interface StageRow { id: string; key: string; label: string; order: number; isActive: boolean; requiredRole?: { key: string; label: string } | null }
interface ConfigRow { key: string; value: string; label: string }
interface AuditRow { id: string; action: string; createdAt: string; user?: { fullName: string } | null; bookRequest?: { displayId: string } | null }

export default function AdminConfig() {
  const [users, setUsers] = useState<AdminUser[] | null>(null);
  const [stages, setStages] = useState<StageRow[] | null>(null);
  const [config, setConfig] = useState<ConfigRow[] | null>(null);
  const [auditLogs, setAuditLogs] = useState<AuditRow[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [savingKey, setSavingKey] = useState<string | null>(null);

  function loadAll() {
    api.get<{ users: AdminUser[] }>("/admin/users").then((r) => setUsers(r.users)).catch((e) => setError(e.message));
    api.get<{ stages: StageRow[] }>("/admin/stages").then((r) => setStages(r.stages)).catch((e) => setError(e.message));
    api.get<{ config: ConfigRow[] }>("/admin/config").then((r) => setConfig(r.config)).catch((e) => setError(e.message));
    api.get<{ logs: AuditRow[] }>("/admin/audit").then((r) => setAuditLogs(r.logs)).catch((e) => setError(e.message));
  }

  useEffect(loadAll, []);

  async function updateConfigValue(key: string, value: string) {
    setSavingKey(key);
    try {
      await api.patch(`/admin/config/${key}`, { value });
      loadAll();
    } catch (e) {
      setError(e instanceof ApiClientError ? e.message : "Failed to update config.");
    } finally {
      setSavingKey(null);
    }
  }

  async function toggleStageActive(stage: StageRow) {
    try {
      await api.patch(`/admin/stages/${stage.id}`, { isActive: !stage.isActive });
      loadAll();
    } catch (e) {
      setError(e instanceof ApiClientError ? e.message : "Failed to update stage.");
    }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Admin</h1>
          <p className="subtitle">Users, workflow configuration, and system-wide audit trail.</p>
        </div>
      </div>

      {error && <div className="alert alert-error">{error}</div>}

      <div className="card">
        <h3 style={{ marginTop: 0 }}>Workflow Configuration</h3>
        <p className="subtitle">
          These stages are proposed defaults, not confirmed official college rules — edit freely as the real
          process gets confirmed. Order and active state are read by the workflow engine at runtime.
        </p>
        {stages ? (
          <table className="data-table">
            <thead><tr><th>Order</th><th>Stage</th><th>Required Role</th><th>Active</th><th></th></tr></thead>
            <tbody>
              {stages.map((s) => (
                <tr key={s.id}>
                  <td>{s.order}</td>
                  <td>{s.label} <code style={{ color: "#94a3b8" }}>({s.key})</code></td>
                  <td>{s.requiredRole?.label || "—"}</td>
                  <td>{s.isActive ? "Yes" : "No"}</td>
                  <td>
                    <button className="btn btn-secondary btn-sm" onClick={() => toggleStageActive(s)}>
                      {s.isActive ? "Deactivate" : "Activate"}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          "Loading..."
        )}
      </div>

      <div className="card">
        <h3 style={{ marginTop: 0 }}>System Configuration</h3>
        {config ? (
          config.map((c) => (
            <div key={c.key} className="form-field" style={{ marginBottom: 12, maxWidth: 480 }}>
              <label>{c.label} ({c.key})</label>
              <div style={{ display: "flex", gap: 8 }}>
                <input
                  defaultValue={c.value}
                  onBlur={(e) => e.target.value !== c.value && updateConfigValue(c.key, e.target.value)}
                />
                {savingKey === c.key && <span className="subtitle">Saving...</span>}
              </div>
            </div>
          ))
        ) : (
          "Loading..."
        )}
      </div>

      <div className="card">
        <h3 style={{ marginTop: 0 }}>Users</h3>
        {users ? (
          <table className="data-table">
            <thead><tr><th>Name</th><th>Email</th><th>Roles</th><th>Demo</th><th>Active</th></tr></thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id}>
                  <td>{u.fullName}</td>
                  <td>{u.email}</td>
                  <td>{u.roles.join(", ")}</td>
                  <td>{u.isDemo ? "Yes" : "No"}</td>
                  <td>{u.isActive ? "Yes" : "No"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          "Loading..."
        )}
      </div>

      <div className="card">
        <h3 style={{ marginTop: 0 }}>System-wide Audit Log (latest 200)</h3>
        {auditLogs ? (
          auditLogs.map((a) => (
            <div className="audit-row" key={a.id}>
              <span className="audit-time">{new Date(a.createdAt).toLocaleString()}</span>
              <span>
                <strong>{a.action.replaceAll("_", " ")}</strong>
                {a.user ? ` by ${a.user.fullName}` : ""} {a.bookRequest ? `on ${a.bookRequest.displayId}` : ""}
              </span>
            </div>
          ))
        ) : (
          "Loading..."
        )}
      </div>
    </div>
  );
}

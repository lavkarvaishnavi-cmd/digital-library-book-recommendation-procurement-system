import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import fs from "fs";
import path from "path";
import { DEFAULT_STAGES, DEFAULT_CONFIG } from "../src/config/workflow";

const prisma = new PrismaClient();

const ROLE_DEFS = [
  { key: "STUDENT", label: "Student" },
  { key: "FACULTY", label: "Faculty" },
  { key: "SUBJECT_INCHARGE", label: "Subject In-charge" },
  { key: "HOD", label: "Head of Department" },
  { key: "PRINCIPAL", label: "Principal" },
  { key: "LIBRARIAN", label: "Librarian" },
  { key: "PROCUREMENT_ADMIN", label: "Procurement / Admin" },
  { key: "SYSTEM_ADMIN", label: "System Administrator" },
];

const DEMO_PASSWORD = "Demo@123";

const DEMO_USERS = [
  { email: "demo.student@college.edu", fullName: "Aarav Sharma (Demo Student)", roleKey: "STUDENT", department: "CSE" },
  { email: "demo.student2@college.edu", fullName: "Isha Verma (Demo Student)", roleKey: "STUDENT", department: "CSE" },
  { email: "demo.faculty@college.edu", fullName: "Dr. Neha Kulkarni (Demo Faculty)", roleKey: "FACULTY", department: "CSE" },
  { email: "demo.incharge@college.edu", fullName: "Prof. Ramesh Deshmukh (Demo Subject In-charge)", roleKey: "SUBJECT_INCHARGE", department: "CSE" },
  // One HOD per department, since each department approves its own students' requests.
  { email: "demo.hod@college.edu", fullName: "Dr. Suresh Patil (Demo HOD - CSE)", roleKey: "HOD", department: "CSE" },
  { email: "demo.hod.civil@college.edu", fullName: "Dr. Meera Joshi (Demo HOD - Civil)", roleKey: "HOD", department: "CIVIL" },
  { email: "demo.hod.mech@college.edu", fullName: "Dr. Rajesh Pawar (Demo HOD - Mechanical)", roleKey: "HOD", department: "MECHANICAL" },
  { email: "demo.hod.aids@college.edu", fullName: "Dr. Snehal Kale (Demo HOD - AI&DS)", roleKey: "HOD", department: "AIDS" },
  { email: "demo.hod.mca@college.edu", fullName: "Dr. Prashant More (Demo HOD - MCA)", roleKey: "HOD", department: "MCA" },
  { email: "demo.principal@college.edu", fullName: "Dr. Anjali Rao (Demo Principal)", roleKey: "PRINCIPAL", department: null },
  { email: "demo.librarian@college.edu", fullName: "Mr. Vikas Jadhav (Demo Librarian)", roleKey: "LIBRARIAN", department: null },
  { email: "demo.procurement@college.edu", fullName: "Ms. Pooja Nair (Demo Procurement)", roleKey: "PROCUREMENT_ADMIN", department: null },
  { email: "demo.admin@college.edu", fullName: "System Administrator (Demo)", roleKey: "SYSTEM_ADMIN", department: null },
];

// Fallback sample catalogue, used only if the real accession-register import
// (prisma/data/library-catalogue.json) is missing for some reason.
const FALLBACK_CATALOGUE = [
  { title: "Introduction to Algorithms", author: "Cormen, Leiserson, Rivest, Stein", publication: "MIT Press", copiesOwned: 5 },
  { title: "Python for Data Analysis", author: "Wes McKinney", publication: "O'Reilly", copiesOwned: 3 },
  { title: "Database System Concepts", author: "Silberschatz, Korth, Sudarshan", publication: "McGraw-Hill", copiesOwned: 4 },
];

async function main() {
  console.log("Seeding roles...");
  const roleRecords: Record<string, string> = {};
  for (const r of ROLE_DEFS) {
    const role = await prisma.role.upsert({
      where: { key: r.key },
      update: { label: r.label },
      create: { key: r.key, label: r.label },
    });
    roleRecords[r.key] = role.id;
  }

  console.log("Seeding workflow stages...");
  for (const s of DEFAULT_STAGES) {
    await prisma.workflowStage.upsert({
      where: { key: s.key },
      update: {
        label: s.label,
        order: s.order,
        requiredRoleId: s.roleKey ? roleRecords[s.roleKey] : null,
        requiresSupport: s.requiresSupport,
        isTerminal: s.isTerminal,
      },
      create: {
        key: s.key,
        label: s.label,
        order: s.order,
        requiredRoleId: s.roleKey ? roleRecords[s.roleKey] : null,
        requiresSupport: s.requiresSupport,
        isTerminal: s.isTerminal,
      },
    });
  }

  console.log("Seeding system config...");
  for (const c of DEFAULT_CONFIG) {
    await prisma.systemConfig.upsert({
      where: { key: c.key },
      update: {},
      create: { key: c.key, value: c.value, label: c.label },
    });
  }

  console.log("Seeding demo users (DEMO ONLY, hashed passwords)...");
  const passwordHash = await bcrypt.hash(DEMO_PASSWORD, 10);
  for (const u of DEMO_USERS) {
    const user = await prisma.user.upsert({
      where: { email: u.email },
      update: { fullName: u.fullName, isDemo: true, department: u.department },
      create: { email: u.email, fullName: u.fullName, passwordHash, isDemo: true, department: u.department },
    });
    await prisma.userRole.upsert({
      where: { userId_roleId: { userId: user.id, roleId: roleRecords[u.roleKey] } },
      update: {},
      create: { userId: user.id, roleId: roleRecords[u.roleKey] },
    });
  }

  console.log("Seeding library catalogue...");
  const existingCount = await prisma.catalogueBook.count();
  if (existingCount === 0) {
    const dataPath = path.join(__dirname, "data", "library-catalogue.json");
    let catalogue: { title: string; author: string; publication: string | null; copiesOwned: number }[];
    if (fs.existsSync(dataPath)) {
      catalogue = JSON.parse(fs.readFileSync(dataPath, "utf-8"));
      console.log(`  Loading ${catalogue.length} titles from the real accession register (library-catalogue.json)...`);
    } else {
      catalogue = FALLBACK_CATALOGUE;
      console.log("  library-catalogue.json not found — seeding a small fallback sample instead.");
    }
    // Batch inserts — a few thousand rows in one createMany call can be slow/risky.
    const BATCH = 500;
    for (let i = 0; i < catalogue.length; i += BATCH) {
      await prisma.catalogueBook.createMany({ data: catalogue.slice(i, i + BATCH) });
    }
  }

  console.log("Seeding demo book requests at different workflow stages...");
  await seedDemoRequests();

  console.log("Seed complete.");
  console.log(`Demo login password for all seeded accounts: ${DEMO_PASSWORD}`);
}

/**
 * Creates a handful of demo BookRequest records already sitting at different
 * points in the workflow, so the app is useful to explore immediately after
 * seeding rather than starting completely empty. All clearly demo data.
 */
async function seedDemoRequests() {
  const existing = await prisma.bookRequest.count();
  if (existing > 0) {
    console.log("  Demo requests already exist, skipping.");
    return;
  }

  const byEmail = async (email: string) => prisma.user.findUniqueOrThrow({ where: { email } });
  const student1 = await byEmail("demo.student@college.edu");
  const student2 = await byEmail("demo.student2@college.edu");
  const incharge = await byEmail("demo.incharge@college.edu");
  const hod = await byEmail("demo.hod@college.edu");
  const principal = await byEmail("demo.principal@college.edu");
  const librarian = await byEmail("demo.librarian@college.edu");
  const procurementAdmin = await byEmail("demo.procurement@college.edu");

  const year = new Date().getFullYear();
  let seq = 1;
  const nextId = () => `BR-${year}-${String(seq++).padStart(4, "0")}`;

  // 1) DRAFT — just created, not yet submitted.
  await prisma.bookRequest.create({
    data: {
      displayId: nextId(),
      requestedById: student1.id,
      currentStageKey: "DRAFT",
      status: "DRAFT",
      items: { create: [{ author: "Charles Petzold", title: "Code: The Hidden Language", copiesRequired: 1, remark: "For personal reading" }] },
      auditLogs: { create: [{ userId: student1.id, roleKeyAtTime: "STUDENT", action: "REQUEST_CREATED" }] },
    },
  });

  // 2) SUPPORT_COLLECTION — submitted, gathering support (1 of demo threshold).
  const req2 = await prisma.bookRequest.create({
    data: {
      displayId: nextId(),
      requestedById: student2.id,
      currentStageKey: "SUPPORT_COLLECTION",
      status: "SUPPORT_COLLECTION",
      items: { create: [{ author: "Wes McKinney", title: "Python Data Analysis (3rd ed.)", publication: "O'Reilly", copiesRequired: 2, approxCost: 1200, remark: "Newer edition than the one we own" }] },
      auditLogs: { create: [
        { userId: student2.id, roleKeyAtTime: "STUDENT", action: "REQUEST_CREATED" },
        { userId: student2.id, roleKeyAtTime: "STUDENT", action: "REQUEST_SUBMITTED" },
      ] },
    },
  });
  await prisma.support.create({ data: { bookRequestId: req2.id, userId: student1.id, comment: "Need this for my project too" } });

  // 3) HOD_REVIEW — subject in-charge already approved.
  const req3 = await prisma.bookRequest.create({
    data: {
      displayId: nextId(),
      requestedById: student1.id,
      currentStageKey: "HOD_REVIEW",
      status: "HOD_REVIEW",
      items: { create: [{ author: "Aurelien Geron", title: "Hands-On Machine Learning with Scikit-Learn, Keras & TensorFlow", publication: "O'Reilly", copiesRequired: 3, approxCost: 4500 }] },
      approvals: { create: [{ stageKey: "UNDER_REVIEW", actorId: incharge.id, roleKeyAtTime: "SUBJECT_INCHARGE", decision: "APPROVE", comment: "Relevant to the AI/DS elective syllabus." }] },
      auditLogs: { create: [
        { userId: student1.id, roleKeyAtTime: "STUDENT", action: "REQUEST_CREATED" },
        { userId: student1.id, roleKeyAtTime: "STUDENT", action: "REQUEST_SUBMITTED" },
        { userId: incharge.id, roleKeyAtTime: "SUBJECT_INCHARGE", action: "APPROVED" },
      ] },
    },
  });

  // 4) PROCUREMENT — approved all the way through, librarian confirmed unavailable.
  const req4 = await prisma.bookRequest.create({
    data: {
      displayId: nextId(),
      requestedById: student2.id,
      currentStageKey: "PROCUREMENT",
      status: "PROCUREMENT",
      items: { create: [{ author: "Ian Goodfellow, Yoshua Bengio, Aaron Courville", title: "Deep Learning", publication: "MIT Press", copiesRequired: 2, approxCost: 3800 }] },
      approvals: { create: [
        { stageKey: "UNDER_REVIEW", actorId: incharge.id, roleKeyAtTime: "SUBJECT_INCHARGE", decision: "APPROVE" },
        { stageKey: "HOD_REVIEW", actorId: hod.id, roleKeyAtTime: "HOD", decision: "APPROVE" },
        { stageKey: "PRINCIPAL_REVIEW", actorId: principal.id, roleKeyAtTime: "PRINCIPAL", decision: "APPROVE", comment: "Procure within 1 month." },
      ] },
      procurement: { create: { availableInLibrary: false, orderSentTo: "M/s Academic Book House, Amravati" } },
      auditLogs: { create: [
        { userId: student2.id, roleKeyAtTime: "STUDENT", action: "REQUEST_SUBMITTED" },
        { userId: incharge.id, roleKeyAtTime: "SUBJECT_INCHARGE", action: "APPROVED" },
        { userId: hod.id, roleKeyAtTime: "HOD", action: "APPROVED" },
        { userId: principal.id, roleKeyAtTime: "PRINCIPAL", action: "APPROVED" },
        { userId: librarian.id, roleKeyAtTime: "LIBRARIAN", action: "LIBRARIAN_SENT_TO_PROCUREMENT" },
      ] },
    },
  });
  void req4;

  // 5) COMPLETED — full cycle finished, book accessioned.
  const req5 = await prisma.bookRequest.create({
    data: {
      displayId: nextId(),
      requestedById: student1.id,
      currentStageKey: "COMPLETED",
      status: "COMPLETED",
      items: { create: [{ author: "Andrew S. Tanenbaum", title: "Computer Networks (6th ed.)", publication: "Pearson", copiesRequired: 2, approxCost: 2200 }] },
      approvals: { create: [
        { stageKey: "UNDER_REVIEW", actorId: incharge.id, roleKeyAtTime: "SUBJECT_INCHARGE", decision: "APPROVE" },
        { stageKey: "HOD_REVIEW", actorId: hod.id, roleKeyAtTime: "HOD", decision: "APPROVE" },
        { stageKey: "PRINCIPAL_REVIEW", actorId: principal.id, roleKeyAtTime: "PRINCIPAL", decision: "APPROVE" },
      ] },
      procurement: {
        create: {
          availableInLibrary: false,
          orderSentTo: "M/s Academic Book House, Amravati",
          orderNumber: "ORD-2026-014",
          orderDate: new Date(),
          totalBudget: 50000,
          orderAmount: 2200,
          balanceAvailable: 47800,
          billNumber: "BILL-778",
          billDate: new Date(),
          billAmount: 2200,
          accessionedAt: new Date(),
        },
      },
      auditLogs: { create: [
        { userId: student1.id, roleKeyAtTime: "STUDENT", action: "REQUEST_SUBMITTED" },
        { userId: principal.id, roleKeyAtTime: "PRINCIPAL", action: "APPROVED" },
        { userId: procurementAdmin.id, roleKeyAtTime: "PROCUREMENT_ADMIN", action: "PROCUREMENT_ORDER_RECORDED" },
        { userId: procurementAdmin.id, roleKeyAtTime: "PROCUREMENT_ADMIN", action: "COMPLETED" },
      ] },
    },
  });
  void req5;

  // 6) REJECTED — turned down at HOD stage.
  await prisma.bookRequest.create({
    data: {
      displayId: nextId(),
      requestedById: student2.id,
      currentStageKey: "REJECTED",
      status: "REJECTED",
      items: { create: [{ author: "Unknown", title: "Outdated Programming Manual (1998 ed.)", copiesRequired: 1, approxCost: 400 }] },
      approvals: { create: [
        { stageKey: "UNDER_REVIEW", actorId: incharge.id, roleKeyAtTime: "SUBJECT_INCHARGE", decision: "APPROVE" },
        { stageKey: "HOD_REVIEW", actorId: hod.id, roleKeyAtTime: "HOD", decision: "REJECT", comment: "Content is outdated; a newer edition is already in the syllabus list." },
      ] },
      auditLogs: { create: [
        { userId: student2.id, roleKeyAtTime: "STUDENT", action: "REQUEST_SUBMITTED" },
        { userId: hod.id, roleKeyAtTime: "HOD", action: "REJECTED" },
      ] },
    },
  });
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

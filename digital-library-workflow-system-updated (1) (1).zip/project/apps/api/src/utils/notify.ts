import { prisma } from "../lib/prisma";

/**
 * Creates an in-app notification for a user. Email delivery is a documented
 * future integration (see sendEmailStub) — not built for v1 since it wasn't
 * requested as a hard requirement and needs real SMTP/provider credentials.
 */
export async function notifyUser(userId: string, message: string, bookRequestId?: string) {
  await prisma.notification.create({
    data: { userId, message, bookRequestId },
  });
}

export async function notifyUsersWithRole(roleKey: string, message: string, bookRequestId?: string) {
  const users = await prisma.user.findMany({
    where: { isActive: true, roles: { some: { role: { key: roleKey } } } },
    select: { id: true },
  });
  await Promise.all(users.map((u) => notifyUser(u.id, message, bookRequestId)));
}

/** Placeholder for a future real email integration (SMTP / provider API). */
export async function sendEmailStub(to: string, subject: string, body: string) {
  // eslint-disable-next-line no-console
  console.log(`[email-stub] Would send to ${to}: ${subject} — ${body}`);
}

/**
 * Default workflow stage seed data.
 *
 * IMPORTANT: this sequence is a proposed default, not a confirmed official
 * college process. It is written into the WorkflowStage table by prisma/seed.ts
 * and can be edited afterwards from Admin -> Workflow Configuration without any
 * code changes. Nothing downstream hard-codes this list; the workflow engine
 * (src/services/workflowEngine.ts) always reads from the database.
 */
export const DEFAULT_STAGES = [
  { key: "DRAFT", label: "Request Created", order: 0, roleKey: null, requiresSupport: false, isTerminal: false },
  { key: "SUBMITTED", label: "Submitted", order: 1, roleKey: null, requiresSupport: false, isTerminal: false },
  { key: "SUPPORT_COLLECTION", label: "Support Collection", order: 2, roleKey: null, requiresSupport: true, isTerminal: false },
  { key: "UNDER_REVIEW", label: "Subject In-charge Review", order: 3, roleKey: "SUBJECT_INCHARGE", requiresSupport: false, isTerminal: false },
  { key: "HOD_REVIEW", label: "HOD Review", order: 4, roleKey: "HOD", requiresSupport: false, isTerminal: false },
  { key: "PRINCIPAL_REVIEW", label: "Principal Review", order: 5, roleKey: "PRINCIPAL", requiresSupport: false, isTerminal: false },
  { key: "LIBRARIAN_VERIFICATION", label: "Librarian Verification", order: 6, roleKey: "LIBRARIAN", requiresSupport: false, isTerminal: false },
  { key: "PROCUREMENT", label: "Procurement", order: 7, roleKey: "PROCUREMENT_ADMIN", requiresSupport: false, isTerminal: false },
  { key: "COMPLETED", label: "Completed", order: 8, roleKey: null, requiresSupport: false, isTerminal: true },
  { key: "REJECTED", label: "Rejected", order: 99, roleKey: null, requiresSupport: false, isTerminal: true },
  { key: "RETURNED_FOR_CORRECTION", label: "Returned for Correction", order: 98, roleKey: null, requiresSupport: false, isTerminal: false },
] as const;

export const REVIEW_STAGE_ORDER = ["UNDER_REVIEW", "HOD_REVIEW", "PRINCIPAL_REVIEW"] as const;

export const DEFAULT_CONFIG = [
  { key: "requiredSupportCount", value: "2", label: "Students required to support a request before review (demo default is low for easy testing)" },
  { key: "orgName", value: "P. R. Pote Patil College of Engineering and Management, Amravati", label: "Organization name shown in UI" },
];

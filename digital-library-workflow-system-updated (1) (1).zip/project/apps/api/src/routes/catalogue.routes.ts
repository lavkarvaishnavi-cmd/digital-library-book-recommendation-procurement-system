import { Router } from "express";
import { authenticate } from "../middleware/auth";
import { asyncHandler } from "../middleware/errorHandler";
import { getCatalogueService } from "../services/catalogueService";

const router = Router();

router.get(
  "/search",
  authenticate,
  asyncHandler(async (req, res) => {
    const q = (req.query.q as string) || "";
    const results = await getCatalogueService().search(q);
    res.json({ results, source: "DEMO_CATALOGUE" });
  })
);

router.get(
  "/:id",
  authenticate,
  asyncHandler(async (req, res) => {
    const book = await getCatalogueService().getById(req.params.id);
    if (!book) return res.status(404).json({ error: "Not found" });
    res.json({ book, source: "DEMO_CATALOGUE" });
  })
);

export default router;

import { NextFunction, Request, Response } from "express";
import jwt from "jsonwebtoken";
import { env } from "../config/env";
import { AuthUser } from "../types";
import { ApiError } from "../utils/apiError";

/**
 * Verifies the JWT on every protected route and attaches the authenticated
 * user (id, email, roles) to req.user. Rejects with 401 if missing/invalid.
 * This is the ONLY place identity is established — nothing downstream should
 * trust a role or user id sent in the request body.
 */
export function authenticate(req: Request, _res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith("Bearer ")) {
    return next(new ApiError(401, "Authentication required."));
  }
  const token = header.slice("Bearer ".length);
  try {
    const payload = jwt.verify(token, env.jwtSecret) as AuthUser;
    req.user = payload;
    next();
  } catch {
    next(new ApiError(401, "Invalid or expired session. Please log in again."));
  }
}

/**
 * Role-based authorization guard. Usage: authorize("HOD", "PRINCIPAL")
 * Rejects with 403 if the authenticated user holds none of the given roles.
 * This check happens on the server regardless of what the frontend renders —
 * a STUDENT token can never pass authorize("PRINCIPAL").
 */
export function authorize(...allowedRoles: string[]) {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user) return next(new ApiError(401, "Authentication required."));
    const hasRole = req.user.roles.some((r) => allowedRoles.includes(r));
    if (!hasRole) {
      return next(
        new ApiError(
          403,
          `Forbidden: this action requires one of [${allowedRoles.join(", ")}].`
        )
      );
    }
    next();
  };
}

import { z } from "zod";

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

export const createRequestItemSchema = z.object({
  author: z.string().min(1).max(200),
  title: z.string().min(1).max(300),
  publication: z.string().max(200).optional(),
  copiesRequired: z.number().int().min(1).max(1000).default(1),
  approxCost: z.number().min(0).max(10_000_000).optional(),
  remark: z.string().max(500).optional(),
  neededWithinDays: z.number().int().min(1).max(365).optional(),
  photocopyAcceptable: z.boolean().default(false),
});

export const createRequestSchema = z.object({
  items: z.array(createRequestItemSchema).min(1),
});

export const addItemSchema = createRequestItemSchema;

export const supportSchema = z.object({
  comment: z.string().max(300).optional(),
});

export const decisionSchema = z.object({
  decision: z.enum(["APPROVE", "REJECT", "RETURN"]),
  comment: z.string().max(1000).optional(),
});

export const librarianVerifySchema = z.object({
  availableInLibrary: z.boolean(),
  comment: z.string().max(500).optional(),
});

export const procurementCreateSchema = z.object({
  orderSentTo: z.string().max(300).optional(),
  orderNumber: z.string().max(100).optional(),
  orderDate: z.string().datetime().optional(),
  totalBudget: z.number().min(0).optional(),
  orderAmount: z.number().min(0).optional(),
});

export const procurementUpdateSchema = z.object({
  orderSentTo: z.string().max(300).optional(),
  orderNumber: z.string().max(100).optional(),
  orderDate: z.string().datetime().optional(),
  totalBudget: z.number().min(0).optional(),
  orderAmount: z.number().min(0).optional(),
  billNumber: z.string().max(100).optional(),
  billDate: z.string().datetime().optional(),
  billAmount: z.number().min(0).optional(),
  markAccessioned: z.boolean().optional(),
});

export const cancelRequestSchema = z.object({
  reason: z.string().min(5, "Please explain why you're cancelling (at least 5 characters).").max(500),
});

export const configUpdateSchema = z.object({
  value: z.string().min(1).max(500),
});

export const stageUpdateSchema = z.object({
  label: z.string().min(1).max(200).optional(),
  order: z.number().int().optional(),
  isActive: z.boolean().optional(),
});
